import argparse
import os
import pickle
import pandas as pd
import logging
from tqdm import tqdm
import time
import json
import torch
from transformers import pipeline, AutoModel, AutoTokenizer, AutoModelForCausalLM, GemmaForCausalLM, LlamaTokenizer
from torch.cuda.amp import autocast, GradScaler

# logging
logging.basicConfig(level=logging.WARNING, format='%(levelname)s:%(message)s')

###### TODO set pipeline based on the model 
def load_model_and_tokenizer(model_name):
    if model_name == "gemma":
        model = GemmaForCausalLM.from_pretrained(
            "mustafaaljadery/gemma-2B-10M", 
            torch_dtype=torch.bfloat16, 
            device_map="auto",
            max_memory={
                0: "78GB",  # first GPU
                1: "78GB",  # second GPU
                "cpu": "100GB"  # CPU
            }
        )
        tokenizer = AutoTokenizer.from_pretrained("mustafaaljadery/gemma-2B-10M")

    elif model_name == "llama_gradient":
        model_id = "gradientai/Llama-3-70B-Instruct-Gradient-524k"
        model = AutoModelForCausalLM.from_pretrained(
                model_id,
                torch_dtype=torch.bfloat16,
                device_map="auto",
                max_memory={
                    0: "78GB",  # 1st GPU
                    1: "78GB",  # 2nd GPU
                    2: "78GB",  # 3rd GPU
                    "cpu": "100GB"  # CPU
                }
            )
        tokenizer = AutoTokenizer.from_pretrained(model_id)
        pipe = pipeline(
                "text-generation",
                model=model,
                tokenizer=tokenizer,
                device_map="auto"
            )
        return pipe
    elif model_name == "phi":
        model = AutoModelForCausalLM.from_pretrained(
            "microsoft/Phi-3-mini-128k-instruct", 
            torch_dtype="auto", 
            trust_remote_code=True, 
            device_map="auto"
        )
        tokenizer = AutoTokenizer.from_pretrained("microsoft/Phi-3-mini-128k-instruct")
    elif model_name == "llama_giraffe":
        model_id = "abacusai/Llama-3-Giraffe-70B-Instruct"
        pipe = pipeline(
            "text-generation",
            model=model_id,
            model_kwargs={"torch_dtype": torch.bfloat16},
            device="auto",
            max_memory={
                    0: "78GB",  # 1st GPU
                    1: "78GB",  # 2nd GPU
                    2: "78GB",  # 3rd GPU
                    "cpu": "100GB"  # CPU
                }
        )
        return pipe
    elif model_name == "longllama":
        model = AutoModelForCausalLM.from_pretrained(
            "syzymon/long_llama_3b_instruct", 
            torch_dtype=torch.bfloat16, 
            trust_remote_code=True, 
            device_map="auto"
        )
        tokenizer = LlamaTokenizer.from_pretrained("syzymon/long_llama_3b_instruct")
    else:
        raise ValueError(f"Model {model_name} is not supported")
    
    return model, tokenizer




def load_prompt_template(filename):
    """
    Loads and returns the prompt template from a text file.
    Ensures that the file exists before attempting to open it.
    """
    if not os.path.exists(filename):
        raise FileNotFoundError(f"The prompt template file was not found: {filename}")
    with open(filename, 'r') as file:
        return file.read()

def make_prompt(book_text, claim, template):
    """
    Generates a customized prompt by replacing placeholders in the template with specific values.
    """
    return template.replace("[book_text]", book_text).replace("[claim]", claim)



########################## TODO #################################################
def model_call_gemma(prompt, model, tokenizer, ctx_window=10000000, temp=0.0):
    """
    Model call for gemma-2b-10m: to be implemented
    https://huggingface.co/mustafaaljadery/gemma-2B-10M 
    """
    with torch.no_grad(), autocast():
        inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=ctx_window) #check truncation
        inputs = inputs.to(model.device)
        generate_ids = model.generate(inputs.input_ids, max_new_tokens=600, max_length=ctx_window)
        response = tokenizer.batch_decode(generate_ids, skip_special_tokens=True)[0]
    torch.cuda.empty_cache()
    return response


def model_call_llama_gradient(prompt, pipe, ctx_window=524000, temp=0.0):
    """
    Model call for gradient's llama: to be implemented
    https://huggingface.co/gradientai/Llama-3-70B-Instruct-Gradient-524k
    """
    messages = [{"role": "user", "content": prompt}]
    prompt_template = pipe.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    terminators = [pipe.tokenizer.eos_token_id, pipe.tokenizer.convert_tokens_to_ids("")]
    outputs = pipe(prompt_template, max_new_tokens=600, eos_token_id=terminators, do_sample=True, temperature=temp, top_p=0.9)
    response = outputs[0]["generated_text"][len(prompt_template):]
    torch.cuda.empty_cache()
    return response


def model_call_phi(prompt, model, tokenizer, ctx_window=128000, temp=0.0):
    """
    Model call for Phi-3-mini-128k: to be implemented
    https://huggingface.co/microsoft/Phi-3-mini-128k-instruct
    """
    pipe = pipeline("text-generation", model=model, tokenizer=tokenizer)
    messages = [{"role": "user", "content": prompt}]

    if temp > 0.0:
        # sampling-based generation
        response = pipe(prompt, max_new_tokens=600, temperature=temp, do_sample=True)[0]["generated_text"]
    else:
        # greedy decoding
        response = pipe(prompt, max_new_tokens=600, do_sample=False)[0]["generated_text"]

    # response = pipe(messages, max_new_tokens=600, temperature=temp, do_sample=True)[0]["generated_text"]
    torch.cuda.empty_cache()
    return response


def model_call_llama_giraffe(prompt, pipe, ctx_window=128000, temp=0.6):
    """
    Model call for llamaGiraffe: to be implemented
    https://huggingface.co/abacusai/Llama-3-Giraffe-70B-Instruct
    """
    messages = [{"role": "user", "content": prompt}]
    prompt_template = pipe.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    terminators = [pipe.tokenizer.eos_token_id, pipe.tokenizer.convert_tokens_to_ids("")]
    outputs = pipe(prompt_template, max_new_tokens=600, eos_token_id=terminators, do_sample=True, temperature=temp, top_p=0.9)
    response = outputs[0]["generated_text"][len(prompt_template):]
    torch.cuda.empty_cache()
    return response

def model_call_longllama(prompt, model, tokenizer, ctx_window=256000, temp=0.0):
    """
    Model call for longllama: to be implemented
    https://huggingface.co/syzymon/long_llama_3b_instruct
    """
    with torch.no_grad(), autocast():
        inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=ctx_window)
        inputs = inputs.to(model.device)
        generation_output = model.generate(input_ids=inputs.input_ids, max_new_tokens=600, num_beams=1, do_sample=True, temperature=temp, max_length=ctx_window)
        response = tokenizer.decode(generation_output[0], skip_special_tokens=True)
    torch.cuda.empty_cache()
    return response


########################## END TODO #################################################



def run_on_claims(data_file, books_file, prompt_file, model_name, output_file=None):
    """
    Processes claims by repeatedly prompting the model up to 10 times on failure,
    and updates the 'response-model_name' field in the input JSON file.
    This version will not skip rows where the 'edited' field is TRUE, even if a 'response-model_name' already exists.
    It skips entries with missing book titles or rows where the 'length' field (computed by tiktoken) exceeds ctx_window.
    Optionally saves progress to a new file every 20 calls or updates the input file directly.
    """
    
    with open(books_file, 'rb') as f:
        books = pickle.load(f)
    
    with open(data_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    template = load_prompt_template(prompt_file)

    # ensure response field exists in the JSON
    for entry in data:
        if f'response-{model_name}' not in entry:
            entry[f'response-{model_name}'] = None  # init with None

    update_interval = 20  # number of calls after which to update the file
    processed_count = 0   # counter to track the number of processed claims

    # load the model and tokenizer
    if model_name in ["llama_gradient", "llama_giraffe"]:
        pipe = load_model_and_tokenizer(model_name)
        model = None
        tokenizer = None
    else:
        model, tokenizer = load_model_and_tokenizer(model_name)
        pipe = None
    
    # map model names to their corresponding functions
    model_call_functions = {
        "gemma": model_call_gemma,
        "llama_gradient": model_call_llama_gradient,
        "phi": model_call_phi,
        "llama_giraffe": model_call_llama_giraffe,
        "longllama": model_call_longllama,
    }

    # select the appropriate model call function
    model_call = model_call_functions.get(model_name)
    if not model_call:
        raise ValueError(f"Model {model_name} is not supported")

    ctx_window_dict = {
        "gemma": 10000000,
        "llama_gradient": 524000,
        "phi": 128000,
        "llama_giraffe":128000,
        "longllama": 256000,
    }

    # select the ctx win size
    ctx_window = ctx_window_dict[model_name] 
    
    
    for idx, entry in tqdm(enumerate(data), total=len(data), desc="Verify Claims"):
        
        book_text = books.get(entry['book_title'])
        if book_text is None:
            logging.warning(f'Book title "{entry["book_title"]}" not found in the books dictionary.')
            continue  # Skip entry with missing book text

        prompt = make_prompt(book_text, entry['claim'], template)

        # get tokens by tokenizer
        if model_name in ["llama_gradient", "llama_giraffe"]:
            inputs = pipe.tokenizer(prompt, return_tensors="pt", truncation=True, max_length=ctx_window)
        else:
            inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=ctx_window)
        
        token_length = inputs.input_ids.shape[1]

        # Check conditions to skip entries unless 'edited' is TRUE
        # TODO if tokenizer exists may rewrite the logic to tokenize and use that; 
        # current use precomputed tiktoken len for books (which is likely off for many models but faster for processing )
        # UPDATE: kind of updated the script to address the above, not tested!!!!!!
        if (entry[f'response-{model_name}'] is not None and not entry.get('edited', False)) or token_length > ctx_window - 1000:
            continue  # Skip if response is filled (and not edited) or length is too high


        success = False
        attempt = 0
        response = None
        while not success and attempt < 10:
            try:
                if model_name in ["llama_gradient", "llama_giraffe"]:
                    response = model_call(prompt, pipe)
                else:
                    response = model_call(prompt, model, tokenizer)
                entry[f'response-{model_name}'] = response  # update the response field directly
                success = True  # break the loop after successful call
            except Exception as e:
                logging.error(f"Error on attempt {attempt + 1} for book {entry['book_title']}: {e}")
                attempt += 1
                time.sleep(10)  # sleep between retries
            
            # clear memory
            if response is not None:
                del response
            torch.cuda.empty_cache()

        processed_count += 1
        # save the file every 20 processed entries
        if processed_count % update_interval == 0:
            with open(output_file or data_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
            logging.info(f"Intermediate save after {processed_count} entries.")

    # Final save to ensure all updates are stored
    with open(output_file or data_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    logging.info(f"Final output saved to {output_file or data_file}")



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Verify claims using a model and update responses.")
    parser.add_argument('--prompt', type=str, required=True, help='Path to the prompt template file')
    parser.add_argument('--books', type=str, required=True, help='Path to the pickle file with book texts')
    parser.add_argument('--model_name', type=str, required=True, help='Name of the model to run. Supported models: "gemma", "llama_gradient", "phi", "llama_giraffe", "longllama"')
    parser.add_argument('--input', type=str, required=True, help='Path to the input JSON file')
    parser.add_argument('--output', type=str, help='Optional path to save the updated JSON data (defaults to input file)')

    args = parser.parse_args()
    run_on_claims(args.input, args.books, args.prompt, args.model_name, args.output)
